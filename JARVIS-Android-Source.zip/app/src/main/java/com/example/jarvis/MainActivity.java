package com.example.jarvis;

import android.app.*;
import android.os.*;
import android.content.*;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import android.graphics.Color;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout messages;
    private EditText input;
    private TextToSpeech tts;
    private final int cyan = Color.rgb(0, 220, 255);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(3, 12, 28));
        getWindow().setNavigationBarColor(Color.BLACK);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("fa","IR"));
        });

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 22, 18, 14);
        root.setBackgroundColor(Color.rgb(3, 12, 28));
        setContentView(root);

        TextView title = new TextView(this);
        title.setText("J.A.R.V.I.S");
        title.setTextColor(cyan); title.setTextSize(28); title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(.18f);
        root.addView(title, new LinearLayout.LayoutParams(-1, 58));

        TextView subtitle = new TextView(this);
        subtitle.setText("PERSONAL AI ASSISTANT  •  ONLINE / OFFLINE");
        subtitle.setTextColor(Color.LTGRAY); subtitle.setTextSize(10); subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);

        ScrollView scroll = new ScrollView(this);
        messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(4, 18, 4, 18);
        scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        addMessage("JARVIS", "سلام! من جارویس هستم. می‌توانی تایپ کنی یا دکمه میکروفون را بزنی.", true);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        input = new EditText(this); input.setSingleLine(true);
        input.setHint("پیامت را بنویس...");
        input.setHintTextColor(Color.GRAY); input.setTextColor(Color.WHITE);
        input.setBackgroundTintList(android.content.res.ColorStateList.valueOf(cyan));
        row.addView(input, new LinearLayout.LayoutParams(0, 52, 1));

        Button mic = new Button(this); mic.setText("🎙");
        row.addView(mic, new LinearLayout.LayoutParams(58, 52));
        Button send = new Button(this); send.setText("ارسال");
        row.addView(send, new LinearLayout.LayoutParams(82, 52));
        root.addView(row);

        mic.setOnClickListener(v -> listen());
        send.setOnClickListener(v -> sendText());
    }

    private void addMessage(String who, String msg, boolean assistant) {
        TextView tv = new TextView(this);
        tv.setText(who + "\n" + msg);
        tv.setTextColor(assistant ? cyan : Color.WHITE);
        tv.setTextSize(15); tv.setPadding(14, 12, 14, 12);
        tv.setBackgroundColor(assistant ? Color.rgb(8, 32, 54) : Color.rgb(18, 28, 45));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 7, 0, 7); messages.addView(tv, p);
    }

    private void sendText() {
        String s = input.getText().toString().trim();
        if (s.isEmpty()) return;
        input.setText("");
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(), 0);
        addMessage("شما", s, false);
        String answer = reply(s);
        addMessage("JARVIS", answer, true);
        if (tts != null) tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "jarvis");
    }

    private String reply(String s) {
        String q = s.toLowerCase(new Locale("fa"));
        if (q.contains("سلام")) return "سلام! آماده‌ام کمکت کنم.";
        if (q.contains("ساعت")) return "ساعت دستگاه شما " + new java.text.SimpleDateFormat("HH:mm", new Locale("fa","IR")).format(new Date()) + " است.";
        if (q.contains("تاریخ")) return "امروز " + new java.text.SimpleDateFormat("yyyy/MM/dd", new Locale("fa","IR")).format(new Date()) + " است.";
        if (q.contains("اسم") || q.contains("نام")) return "من JARVIS هستم، دستیار شخصی شما.";
        if (q.contains("خداحافظ")) return "به امید دیدار. هر زمان به من نیاز داشتی آماده‌ام.";
        return "در حال حاضر نسخه پایه جارویس فعال است. پاسخ هوشمند پیشرفته به اتصال امن به سرویس هوش مصنوعی نیاز دارد.";
    }

    private void listen() {
        if (checkSelfPermission("android.permission.RECORD_AUDIO") != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.RECORD_AUDIO"}, 7); return;
        }
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "با JARVIS صحبت کن");
            startActivityForResult(i, 8);
        } catch (Exception e) {
            addMessage("JARVIS", "سرویس تشخیص گفتار روی این دستگاه در دسترس نیست. می‌توانی پیام را تایپ کنی.", true);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 8 && resultCode == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) { input.setText(r.get(0)); sendText(); }
        }
    }

    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
